package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ActionMenuView
import android.widget.TextView
import com.example.myapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
//    val - считывание
//    var - считывание и записывание
//    val zxc:Int = 5
//    val qwe:Float = 5.6f

    lateinit var bindingClass : ActivityMainBinding
    var res : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindingClass = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bindingClass.root)

        var num = ""
        bindingClass.button0.setOnClickListener {
                if (num.indexOf("0")!=0)
                    num += "0"
                bindingClass.textViewVvod.text = num
        }
        bindingClass.button1.setOnClickListener {
                num += "1"
                bindingClass.textViewVvod.text = num
        }
        bindingClass.button2.setOnClickListener {
                num += "2"
                bindingClass.textViewVvod.text = num
        }
        bindingClass.button3.setOnClickListener {
                num += "3"
                bindingClass.textViewVvod.text = num
        }
        bindingClass.button4.setOnClickListener {
                num += "4"
                bindingClass.textViewVvod.text = num
        }
        bindingClass.button5.setOnClickListener {
                num += "5"
                bindingClass.textViewVvod.text = num
        }
        bindingClass.button6.setOnClickListener {
                num += "6"
                bindingClass.textViewVvod.text = num
        }
        bindingClass.button7.setOnClickListener {
                num += "7"
                bindingClass.textViewVvod.text = num
        }
        bindingClass.button8.setOnClickListener {
                num += "8"
                bindingClass.textViewVvod.text = num
        }
        bindingClass.button9.setOnClickListener {
                num += "9"
                bindingClass.textViewVvod.text = num
        }
        bindingClass.buttonDel.setOnClickListener {
                if (num == "")
                    bindingClass.textViewVvod.text = "0"
                else
                    num = num.substring(0, num.length-1)
                    bindingClass.textViewVvod.text = num
        }
        bindingClass.buttonPlus.setOnClickListener {
            num += "+"
            bindingClass.textViewVvod.text = num
        }
        bindingClass.buttonMinus.setOnClickListener {
            num += "-"
            bindingClass.textViewVvod.text = num
        }
        bindingClass.buttonYmnoz.setOnClickListener {
            num += "*"
            bindingClass.textViewVvod.text = num
        }
        bindingClass.buttonProcent.setOnClickListener {
            num += "%"
            bindingClass.textViewVvod.text = num
        }
        bindingClass.buttonDelen.setOnClickListener {
            num += "/"
            bindingClass.textViewVvod.text = num
        }
        bindingClass.buttonRavn.setOnClickListener {
            var ind = 0
            var num1 = 0
            var num2 = 0

            if (num.indexOf("%") != -1) {
                ind = num.indexOf("%")
                num1 = num.substring(0, ind).toInt()
                res = num1 / 100
            }
            if (num.indexOf("+") != -1){
                ind = num.indexOf("+")
                num1 = num.substring(0, ind).toInt()
                num2 = num.substring(ind+1, num.length).toInt()
                res = num1 + num2
            }
            if (num.indexOf("/") != -1) {
                ind = num.indexOf("/")
                num1 = num.substring(0, ind).toInt()
                num2 = num.substring(ind+1, num.length).toInt()
                res = num1 / num2
            }
            if (num.indexOf("*") != -1) {
                ind = num.indexOf("*")
                num1 = num.substring(0, ind).toInt()
                num2 = num.substring(ind+1, num.length).toInt()
                res = num1 * num2
            }
            if (num.indexOf("-") != -1) {
                ind = num.indexOf("-")
                num1 = num.substring(0, ind).toInt()
                num2 = num.substring(ind+1, num.length).toInt()
                res = num1 - num2
            }

            bindingClass.textViewRes.text = res.toString()
            num = res.toString()
            bindingClass.textViewVvod.text = num
        }

        bindingClass.buttonAC.setOnClickListener {
            num = ""
            res = 0
            bindingClass.textViewRes.text = res.toString()
            bindingClass.textViewVvod.text = "0"
        }
    }
}
